# Media Pembelajaran Interaktif: Papan Tulis Digital (PTD)

Mengoptimalkan Pembelajaran Interaktif dengan Papan Tulis Digital (PTD).
Transformasi Media Ajar Konvensional Menjadi Ruang Kolaborasi Digital.

**Presenter:** Muh. Agustan, S.Pd
**Target audien:** Guru / Pendidik

## Fitur
- 8 slide interaktif (perbandingan, kartu prinsip, tab alur pembelajaran, tab mata pelajaran, kuis Do/Don't, polling)
- Speaker Notes (tombol Notes atau tekan `N`)
- Navigasi tombol atau panah keyboard, tema terang/gelap
- Satu file `index.html`, tanpa instalasi, berjalan offline

## Cara menjalankan
Buka `index.html` di browser.

## Cara publikasi di GitHub Pages
1. Buat repository baru di github.com (misalnya `media-ptd`), set Public.
2. Klik **Add file > Upload files**, unggah semua isi folder ini (`index.html`, `README.md`, `.nojekyll`), lalu **Commit changes**.
3. Buka **Settings > Pages**. Pada **Source** pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu **Save**.
4. Tunggu 1-2 menit. Alamat: `https://USERNAME.github.io/media-ptd/`
